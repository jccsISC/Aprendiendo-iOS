import Foundation

//eL posible acceso a un valor nil
//opcionales
let myString = "12345"
let myInt = Int(myString)
print(myInt)

if myInt != nil {
    print(myInt! + 10)
}

//definir opcionales
var myNewString: String?
print(myNewString)

myNewString = "Suscribete"
print(myNewString)

if myNewString != nil {
    print(myNewString!)
}

//enlace opcional para evitar la comprobaciòn anterior
if let myNoNilString = myNewString {
    print(myNoNilString)
}
