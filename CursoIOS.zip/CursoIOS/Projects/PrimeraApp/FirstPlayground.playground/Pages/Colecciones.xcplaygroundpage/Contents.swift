import Foundation

//coleccion o diccionarios es no ordenada, no se repiten datos
//sintaxis
let myOldDictionary = Dictionary<String, Int>()//creacion de diccionario vacio clasico
var myNewDictionary = [String:Int]() //forma actual
//cuando no nos importe el orden usaremos colecciones
//añadir valores
myNewDictionary = ["Julio":002, "Camacho":001, "Silva":003]
print(myNewDictionary)

//añadir un nuevo dato
myNewDictionary["ISC"] = 004
myNewDictionary["GS"] = 005
print(myNewDictionary)

//acceso a un dato
print(myNewDictionary["Julio"])
print(myNewDictionary["Pedro"])

//actualizar un dato
myNewDictionary["Julio"] = 012
myNewDictionary.updateValue(013, forKey: "Julio")
print(myNewDictionary["Julio"])

//eliminar un dato
myNewDictionary["Julio"] = nil //actual
myNewDictionary.removeValue(forKey: "Julio") //clasica
print(myNewDictionary["Julio"])
