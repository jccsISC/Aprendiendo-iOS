//: [Previous](@previous)

import Foundation

let myNumber = 1

//if
if myNumber < 10 {
//    if
    print("\(myNumber) es menor que 10")
}else {
//    else
    print("\(myNumber) es mayor que 10")
}

if myNumber > 5 && myNumber < 10 {
    print("\(myNumber) es mayor que 5 y menor a 10")
}else {
    print("\(myNumber) es menor o igual a 5 y mayor o igual que 10")
}

if (myNumber > 5 && myNumber < 10) || myNumber >= 50 {
    print("\(myNumber) es mayor que 5 y menor a 10 o mayoro igual que 50")
}else if myNumber == 1 {
    print("myNumber es igual a 1")
}else {
    print("\(myNumber) es menor o igual a 5 y mayor o igual que 10 o  menor que 50")
}


//switch con String
let country = "Mexico"
switch country {
case "Mexico", "España":
    print("El idioma es español")
case "Peru":
    print("El idioma es español")

default:
    print("No  conocemos el idioma")
}

//switch con int
let age = 10
switch age {
case 0, 1, 2:
    print("Es un bebè")
case 3...10:
    print("Es un niño")
case 11..<18:
    print("Es un adolecente")
case 18..<70:
    print("Es un adulto")
case 70..<100:
    print("Es  un anciano")
default:
    print(":O")
}
