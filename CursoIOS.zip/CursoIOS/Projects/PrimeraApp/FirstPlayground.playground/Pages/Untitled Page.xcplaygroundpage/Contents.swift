import UIKit

var greeting = "Hello, playground"
var num = 5

if num  >= 5 {
    print(num,"es igual a 5")
}

//String
let myString = "Hello" //constante
let myString2 = "Bienvenido"
let mystring3 = myString + " " + myString2
print(mystring3)

//Int
let myInt = 5
let myInt2 = 2
print(myInt + myInt2)

//Double
let myDouble = 5.4
let myDouble2 = 3.6
print(myDouble + myDouble2)

//float
let myFloat: Float = 1.5
let myFloat2: Float = 1.5
print(myFloat + myFloat2)

//Bool
let myBool = true
let myBool2 = false
print(myBool)
print(myBool && myBool2)
print(myBool == myBool2)
