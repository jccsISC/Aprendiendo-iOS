//: [Previous](@previous)

import Foundation

//Arrays
let name = "Julio"
let surname = "JccsISC"
let company = "Developer"
let age = "26"

let myArray = Array<String>() //modo clasico
var myArrayModern = [String]() //modo  moderno
let myArrayInferido = ["Hola", "Array inferido"] //array inferido con valores
print(myArrayInferido)

//añadir  datos
myArrayModern.append(name)
myArrayModern.append(surname)
myArrayModern.append(company)
myArrayModern.append(age)
print(myArrayModern)

//añadir un conjunto de  datos
myArrayModern.append(contentsOf: ["Dale like", "Suscribete"])
myArrayModern += ["Nuevo valor"] //esto es lo mismo que el append
print(myArrayModern)

//acceso a datos
print(myArrayModern[0])
//modificando datos
myArrayModern[5] = "Suscribete y activa la campana"
print(myArrayModern)
//eliminar datos
myArrayModern.remove(at: 3)
print(myArrayModern)
//recorrer datos
for value in myArrayModern {
    print(value)
}

