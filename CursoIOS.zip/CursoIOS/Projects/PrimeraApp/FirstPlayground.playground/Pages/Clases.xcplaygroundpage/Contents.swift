import Foundation

class Programmer {
    let name: String
    let age: Int
    let languages: [Language]
    var friends: [Programmer]? //puede ser nulo por eso no la inicializaremos
    
    enum Language {
        case swift
        case kotlin
        case java
        case javascript
    }
    
//    necesita un inicializador
    init(name: String, age: Int, languages: [Language]) {
        self.name = name
        self.age = age
        self.languages = languages
    }
    
    func code(){
        print("Estoy programando \(languages)")
    }
}

//crear una instancia de la clase
let julio = Programmer(name: "Julio", age: 26, languages: [.kotlin,  .swift])
julio.code()
let sara = Programmer(name: "Sara", age: 27, languages: [.java])
sara.code()

julio.friends = [sara]
print(julio.friends?.first?.name)
