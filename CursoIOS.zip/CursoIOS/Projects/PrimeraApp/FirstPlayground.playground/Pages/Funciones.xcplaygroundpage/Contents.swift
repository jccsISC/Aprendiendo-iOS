//: [Previous](@previous)

import Foundation

//Funciones
//funcion simple
func sayHello() {
    print("Hello")
}
sayHello()

//funcion con un parametro de entrada
func sayMyName(name: String) {
    print("Hola mi nombre es: \(name)")
}
sayMyName(name: "Julio")
sayMyName(name: "Cesar")

//funcion con mas parametros
func sayMyNameAndAge(name: String, age: Int) {
    print("Mi nombre es: \(name) y mi edad es \(age)")
}
sayMyNameAndAge(name: "Julio", age: 26)

//funcion con un valor de retorno
func helloString() -> String {
    return "Hola"
}
print(helloString())

//funcion con valor de retorno y entrada de parametros
func sumTwoNumber(num1: Int, num2: Int) -> Int {
    return num1 + num2
}
print("La suma es",sumTwoNumber(num1: 4, num2: 5))
//funcion que llama otra funcion
func callFunctions() {
    sayHello()
    sayMyName(name: "Julio")
    sayMyNameAndAge(name: "Julio", age: 26)
    print(helloString())
    print(sumTwoNumber(num1: 5, num2: 5))
}

callFunctions()
