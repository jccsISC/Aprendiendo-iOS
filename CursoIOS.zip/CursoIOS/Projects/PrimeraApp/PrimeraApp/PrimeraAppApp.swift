//
//  PrimeraAppApp.swift
//  PrimeraApp
//
//  Created by Gustavo Téllez Díaz  on 27/06/21.
//

import SwiftUI

@main
struct PrimeraAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
