//
//  HomeViewController.swift
//  iOS-Calculator
//
//  Created by Gustavo Téllez Díaz  on 28/06/21.
//

import UIKit

final class HomeViewController: UIViewController {

    //MARK: -  Inicializacion
    init() {
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK - life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

}
