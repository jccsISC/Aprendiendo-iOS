//
//  AppDelegate.swift
//  iOS-Calculator
//
//  Created by Julio Camacho Silva  on 27/06/21.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    var window: UIWindow? //creamos nuestra variable
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        
//        SetUp
        setUpView()
        
        return true
    }

    //  MARK: - Privatemethods
    //Indicaremos que vista se ejecutara primero al  iniciar  la app
    private  func setUpView() {
//        instanciamos nuestravariable window
        window = UIWindow(frame: UIScreen.main.bounds) //para que tome su totalidad de pantalla
//        Instanciamos nuestra vista
        let vc = HomeViewController()
        
        window?.rootViewController  = vc //indicamos que estavista serà la primera
        window?.makeKeyAndVisible() //que se inicie y se muestrevisible
    }
    
}

